import AmberLive from "../components/AmberLive"

export default function AmberPage() {
  return (
    <div style={{display:"flex",justifyContent:"center",alignItems:"center",height:"100vh",background:"#0d0d0d",color:"#fff"}}>
      <AmberLive />
    </div>
  )
}
