
import { create } from 'zustand';

export type VoiceUiState = 'idle' | 'listening' | 'speaking' | 'error';

type UIState = {
  drawerOpen: boolean;
  authOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  openAuth: () => void;
  closeAuth: () => void;
  // Voice panel
  voiceState: VoiceUiState;
  voiceErrorMsg?: string;
  setVoiceState: (s: VoiceUiState, msg?: string) => void;
}

export const useUI = create<UIState>((set) => ({
  drawerOpen: false,
  authOpen: false,
  openDrawer: () => set({ drawerOpen: true }),
  closeDrawer: () => set({ drawerOpen: false }),
  openAuth: () => set({ authOpen: true }),
  closeAuth: () => set({ authOpen: false }),
  voiceState: 'idle',
  voiceErrorMsg: undefined,
  setVoiceState: (s, msg) => set({ voiceState: s, voiceErrorMsg: msg }),
}));


