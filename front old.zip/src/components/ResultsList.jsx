import React, { useEffect, useState } from "react";
import "./ResultsList.css";

export default function ResultsList({ results }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 0); return () => clearTimeout(t); }, []);
  if (!results || results.length === 0) return null;

  return (
    <div className="results-container space-y-4">
      {results.map((r, i) => (
        <div
          key={i}
          className={`glass-card p-4 cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:bg-white/10 group ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
          style={{ transitionDelay: `${i * 100}ms` }}
        >
          <div className="flex items-start gap-4">
            {/* Restaurant Icon */}
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500/20 to-orange-600/20 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform duration-300">
              🍕
            </div>
            
            {/* Content */}
            <div className="flex-1">
              <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-orange-300 transition-colors">
                {r.name || r.title || "Bez nazwy"}
              </h3>
              
              <div className="space-y-1">
                {r.address && (
                  <div className="flex items-center gap-2 text-gray-300 text-sm">
                    <span className="text-orange-400">📍</span>
                    <span>{r.address}</span>
                  </div>
                )}
                {r.phone && (
                  <div className="flex items-center gap-2 text-gray-300 text-sm">
                    <span className="text-orange-400">📞</span>
                    <span>{r.phone}</span>
                  </div>
                )}
                {r.hours && (
                  <div className="flex items-center gap-2 text-gray-300 text-sm">
                    <span className="text-orange-400">⏰</span>
                    <span>{r.hours}</span>
                  </div>
                )}
              </div>
              
              {/* Action Button */}
              <div className="mt-3">
                <button className="btn-glass px-4 py-2 text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                  Wybierz restaurację
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}


