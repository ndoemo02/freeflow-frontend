import React from "react";
import { useUI } from "../state/ui";

export default function VoiceDock() {
  const { voiceState, voiceErrorMsg, setVoiceState } = useUI();

  let statusMsg = "";
  switch (voiceState) {
    case "idle":
      statusMsg = "Kliknij, aby mówić";
      break;
    case "listening":
      statusMsg = "Słucham...";
      break;
    case "speaking":
      statusMsg = "Mówię...";
      break;
    case "error":
      statusMsg = voiceErrorMsg || "Błąd mikrofonu";
      break;
    default:
      statusMsg = "";
  }

  return (
    <div className={`voice-dock voice-dock--${voiceState}`} aria-live="polite">
      <button
        className="voice-dock__mic"
        aria-label={statusMsg}
        onClick={() => {
          if (voiceState === "idle" || voiceState === "error") setVoiceState("listening");
          else setVoiceState("idle");
        }}
      >
        {voiceState === "listening" ? "🎤" : voiceState === "speaking" ? "🔊" : "🎙️"}
      </button>
      <span className="voice-dock__status">{statusMsg}</span>
      {voiceState === "error" && (
        <button className="voice-dock__retry" onClick={() => setVoiceState("idle")}>Spróbuj ponownie</button>
      )}
    </div>
  );
}
