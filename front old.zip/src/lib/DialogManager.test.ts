import { dialogManager } from "./DialogManager";

describe("dialogManager integration", () => {
  it("rozpoznaje rozmiar i produkt: 'duża pizza'", async () => {
    const result = await dialogManager("duża pizza", {});
    expect(result.slots.size).toBe("L");
    expect(result.slots.item).toBe("pizza");
    expect(result.speech.toLowerCase()).toContain("łagodna"); // dopytuje o ostrość
  });

  it("rozpoznaje rozmiar i ostrość: 'mały burger ostry'", async () => {
    const result = await dialogManager("mały burger ostry", {});
    expect(result.slots.size).toBe("S");
    expect(result.slots.item).toBe("burger");
    expect(result.slots.spice).toBe("ostra");
  });

  it("resetuje zamówienie na 'od nowa'", async () => {
    const result = await dialogManager("od nowa", { item: "pizza", size: "L" });
    expect(result.slots.item).toBeUndefined();
    expect(result.slots.size).toBeUndefined();
  });
});
