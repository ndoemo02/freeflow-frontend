let unlocked = false;

// bardzo krótka cisza (WAV) – działa w <audio>
const SILENCE =
  'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=';

export async function unlockAudioOnce() {
  if (unlocked) return true;
  try {
    const a = new Audio(SILENCE);
    a.muted = true;                 // bezpieczniej na iOS
    await a.play();
    unlocked = true;
    return true;
  } catch {
    return false;
  }
}

export const isAudioUnlocked = () => unlocked;
