export async function api<T>(input: RequestInfo, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${text || res.statusText}`);
  }
  return res.json() as Promise<T>;
}

export async function tts(text: string, opts?: { lang?: string; voiceName?: string; gender?: string; audioEncoding?: string }): Promise<HTMLAudioElement> {
  const body = JSON.stringify({ text, ...(opts || {}) });
  const { audioContent, contentType } = await api<{ audioContent: string; contentType?: string }>(
    '/api/tts',
    { method: 'POST', body }
  );
  const mime = contentType || 'audio/mpeg';
  const audio = new Audio(`data:${mime};base64,${audioContent}`);
  return audio;
}


