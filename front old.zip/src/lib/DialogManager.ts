
// src/lib/DialogManager.ts

  // ── Typy ───────────────────────────────────────────────────────────────────────
  export type OrderItem = {
    name: string;
    menuItemId?: string;
    price?: number;
    quantity: number;
    notes?: string;
    size?: string;
  };

  export type Slots = {
    // Stare pola dla kompatybilności
    item?: string;
    size?: "S" | "M" | "L";
    spice?: "łagodna" | "ostra";
    toppings?: string[];
    crust?: string;
    dietary?: string;
    time?: string;
    address?: string;
    restaurant?: string;
    restaurantId?: string;
    menuItem?: string;
    menuItemId?: string;
    quantity?: number;
    price?: number;
    // Nowa struktura
    orderItems?: OrderItem[];
  };

  export type TurnResponse = {
    speech: string;
    ui_suggestions?: string[];
    slots: Slots;
    readyToConfirm?: boolean;
    action?: "search_restaurants" | "search_menu" | "add_to_cart" | "checkout";
    searchQuery?: string;
  };

  // ── Pomocnicze ────────────────────────────────────────────────────────────────
  const DEFAULTS: Required<Pick<Slots, "size" | "spice">> = {
    size: "M",
    spice: "łagodna",
  };

  function norm(s: string) {
    return s.normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "") // zdejmij akcenty/ogonki
      .toLowerCase();
  }

  export function mergeSlots(prev: Slots, next?: Partial<Slots>): Slots {
    return { ...prev, ...(next || {}) };
  }
  export function ensureDefaults(slots: Slots): Slots {
    return { ...slots, size: slots.size ?? DEFAULTS.size, spice: slots.spice ?? DEFAULTS.spice };
  }
  export function isReady(slots: Slots) {
    if (slots.orderItems && slots.orderItems.length > 0) {
      return slots.orderItems.every(
        (it) => it.name && it.quantity > 0 && it.price && slots.restaurantId
      );
    }
    return Boolean(slots.item && slots.size && slots.spice);
  }
  function summary(slots: Slots) {
    const size = slots.size || DEFAULTS.size;
    const spice = slots.spice || DEFAULTS.spice;
    const item = slots.item || "pozycja";
    return `${item} ${size}, ${spice}`;
  }

  // ── Ekstrakcja brandu i miasta ────────────────────────────────────────────────
  function extractBrandAndCity(text: string): { brand?: string; city?: string; query: string } {
    const q = norm(text);

    const BRANDS: Array<[RegExp, string]> = [
      [/\bk\s*fc\b/, "kfc"],
      [/\bpizza\s*huts?\b/, "pizza hut"],
      [/\bmc\s*donald'?s?\b/, "mcdonald"],
      [/\bmcdonald'?s?\b/, "mcdonald"],
      [/\bsubway\b/, "subway"],
      [/\bpraha\b/, "praha"],
      [/\bmonte\s*carlo\b/, "monte carlo"],
    ];

    let brand: string | undefined;
    for (const [re, name] of BRANDS) {
      if (re.test(q)) { brand = name; break; }
    }

    // bardzo prosta ekstrakcja miasta po "w ..."
    let city: string | undefined;
    const cityMatch = q.match(/\bw\s+([a-ząćęłńóśźż\s-]{3,})$/i);
    if (cityMatch) {
      const c = cityMatch[1].trim().replace(/\s+/g, " ");
      if (c !== brand) city = c; // unikamy "kfc w kfc"
    }

    // finalne zapytanie do API
    let query = brand || "";
    if (city && city !== brand) query += " " + city;

    return { brand, city, query: query.trim() };
  }

  // ── API ───────────────────────────────────────────────────────────────────────
  async function searchRestaurants(q: string) {
    try {
      console.log("🔍 Searching restaurants for:", q);
      const res = await fetch(`/api/restaurants?q=${encodeURIComponent(q)}`);
      console.log("📡 Restaurant API response:", res.status);
      const data = await res.json();
      console.log("📊 Restaurant data:", data);
      return data.results || [];
    } catch (e) {
      console.error("❌ Error searching restaurants:", e);
      return [];
    }
  }

  async function searchMenuItems(restaurantId: string, q: string) {
    try {
      console.log("🔍 Searching menu for:", restaurantId, "query:", q);
      const res = await fetch(`/api/menu?restaurant_id=${restaurantId}&q=${encodeURIComponent(q)}`);
      console.log("📡 Menu API response:", res.status);
      const data = await res.json();
      console.log("📊 Menu data:", data);
      return data.results || [];
    } catch (e) {
      console.error("❌ Error searching menu items:", e);
      return [];
    }
  }

  // ── Flow "jedno pytanie naraz" ───────────────────────────────────────────────
  function nextStep(slots: Slots): TurnResponse {
    const s = ensureDefaults(slots);
    if (isReady(s)) {
      return {
        speech: `Proponuję ${summary(s)}. Potwierdzasz?`,
        ui_suggestions: [s.size!, s.spice!, "Potwierdź"],
        slots: s,
        readyToConfirm: true,
      };
    }
    if (!s.item) {
      return { speech: "Co podać?", ui_suggestions: ["pizza", "burger"], slots: s };
    }
    if (!s.size) {
      return { speech: "Jaki rozmiar?", ui_suggestions: ["S", "M", "L"], slots: s };
    }
    return { speech: "Łagodna czy ostra?", ui_suggestions: ["Łagodna", "Ostra"], slots: s };
  }


// ── Główna funkcja dialogu ───────────────────────────────────────────────
export async function dialogManager(userText: string, prev: Slots): Promise<TurnResponse> {
  const normalized = (userText || "").toLowerCase().trim();
  let slots: Slots = { ...prev };
  if (/nowe zamówienie|od nowa|wyczyść|resetuj/.test(normalized)) {
    slots = {};
  }

// ── Pomocnicze: rozpoznawanie rozmiaru w 1 miejscu ────────────────────────────
function detectSize(normalized: string): "S" | "M" | "L" | null {
  const sizeVariants: Record<"S" | "M" | "L", string[]> = {
    S: ["mała", "mały", "małe", "small", "mini", "miniature", "s"],
    M: ["średnia", "średnie", "średni", "medium", "normal", "standard", "m"],
    L: ["duża", "duży", "duże", "large", "big", "mega", "x", "xl", "extra", "extra large", "l"],
  };

  let best: { size: "S" | "M" | "L"; len: number } | null = null;
  // dłuższe frazy mają priorytet (np. "extra large" > "xl" > "l")
  const all: Array<{ size: "S" | "M" | "L"; v: string }> = [];
  for (const [size, vs] of Object.entries(sizeVariants) as Array<[ "S"|"M"|"L", string[] ]>) {
    for (const v of vs) all.push({ size, v });
  }
  all.sort((a,b) => b.v.length - a.v.length);

  for (const { size, v } of all) {
    if (normalized.includes(v)) return size;
  }
  return null;
}

  const detectedSize = detectSize(normalized);
  if (detectedSize) {
    return nextStep(ensureDefaults(mergeSlots(slots, { size: detectedSize })));
  }
  if (normalized.includes("łagod")) {
    return nextStep(ensureDefaults(mergeSlots(prev, { spice: "łagodna" })));
  }
  if (normalized.includes("ostr")) {
    return nextStep(ensureDefaults(mergeSlots(slots, { spice: "ostra" })));
  }
  if (normalized.includes("potwierdź") || normalized.includes("zatwierdź")) {
    const finalSlots = ensureDefaults(slots);
    return { speech: `Potwierdzam: ${summary(finalSlots)}. Składam zamówienie.`, ui_suggestions: [], slots: finalSlots, readyToConfirm: true };
  }

  // Szukanie restauracji (brand + opcjonalne miasto)
  {
    const { brand, city, query } = extractBrandAndCity(userText);
    if (brand) {
      console.log("🎯 Restaurant search triggered for:", { brand, city });
      const restaurants = await searchRestaurants(query || brand);
      console.log("🏪 Found restaurants:", restaurants);

      if (restaurants.length > 0) {
        const r = restaurants[0];
        return {
          speech: `Znalazłem ${r.name}${r.city ? ` w ${r.city}` : ""}. Co chciałbyś zamówić?`,
          ui_suggestions: ["Pizza", "Burger", "Frytki"],
          slots: { ...slots, restaurant: r.name, restaurantId: r.id },
          action: "search_menu",
          searchQuery: brand,
        };
      } else {
        return {
          speech: "Nie znalazłem tej restauracji. Spróbuj 'Pizza Hut', 'KFC' albo 'McDonald's'.",
          ui_suggestions: ["Pizza Hut", "KFC", "McDonald's"],
          slots: slots,
        };
      }
    }
  }

  // Wyszukiwanie pozycji menu jeśli znamy restaurację
  if (slots.restaurantId) {
    const wantsMenuList =
      normalized.includes("menu") ||
      normalized.includes("co jest w menu") ||
      normalized.includes("co macie") ||
      normalized.includes("jakie macie");
    if (wantsMenuList) {
      const items = await searchMenuItems(slots.restaurantId, "");
      if (items.length > 0) {
        const top = items.slice(0, 5);
        const names = top.map((i: any) => i.name).join(", ");
        const chips = top.slice(0, 3).map((i: any) => i.name);
        return {
          speech: `W menu mamy m.in.: ${names}. Co wybierasz?`,
          ui_suggestions: chips.length ? chips : ["Pizza", "Burger", "Frytki"],
          slots: { ...slots },
          action: "search_menu",
        };
      } else {
        return {
          speech: "Nie znalazłem pozycji w menu. Spróbuj powiedzieć, na co masz ochotę – np. pizza, burger, frytki.",
          ui_suggestions: ["Pizza", "Burger", "Frytki"],
          slots: { ...slots },
        };
      }
    }
    const productKeywords = [
      "pizza", "burger", "frytki", "cola", "coca", "woda", "kawa", "herbata", 
      "margherita", "pepperoni", "quattro", "stagioni", "hawajska", "capricciosa"
    ];
    const hasProductKeyword = productKeywords.some(keyword => normalized.includes(keyword));
    if (hasProductKeyword) {
      const items = await searchMenuItems(slots.restaurantId, normalized);
      if (items.length > 0) {
        const it = items[0];
        const orderItem: OrderItem = {
          name: it.name,
          menuItemId: it.id,
          price: it.price,
          quantity: 1,
        };
        const orderItems = slots.orderItems ? [...slots.orderItems, orderItem] : [orderItem];
        return {
          speech: `Mamy ${it.name} za ${it.price} zł. Ile sztuk?`,
          ui_suggestions: ["1", "2", "3"],
          slots: { ...slots, menuItem: it.name, menuItemId: it.id, quantity: 1, price: it.price, orderItems },
          action: "add_to_cart",
        };
      } else {
        return {
          speech: `Nie znalazłem "${normalized}" w menu. Spróbuj powiedzieć "pizza", "frytki" lub "cola".`,
          ui_suggestions: ["Pizza", "Frytki", "Cola"],
          slots: { ...slots },
        };
      }
    }
  }

  if (slots.menuItemId && /\d+/.test(normalized)) {
    const qty = parseInt(normalized.match(/\d+/)![0] || "1", 10);
    let orderItems = slots.orderItems ? [...slots.orderItems] : [];
    if (orderItems.length > 0) {
      orderItems[orderItems.length - 1].quantity = qty;
      orderItems[orderItems.length - 1].price = slots.price;
    }
    const total = (slots.price || 0) * qty;
    return {
      speech: `Dodałem ${qty}x ${slots.menuItem} za ${total} zł. Chcesz coś jeszcze?`,
      ui_suggestions: ["Tak", "Nie", "Koszyk"],
      slots: { ...slots, quantity: qty, price: total, orderItems },
      action: "add_to_cart",
    };
  }

  // Rozpoznawanie różnych produktów - rozszerzone
  if (!slots.item) {
    if (normalized.includes("pizza") || normalized.includes("pizze") || normalized.includes("margarita") || normalized.includes("pepperoni") || normalized.includes("hawajska")) {
      slots.item = "pizza";
    } else if (normalized.includes("frytki")) {
      slots.item = "frytki";
    } else if (normalized.includes("burger")) {
      slots.item = "burger";
    } else if (normalized.includes("cola") || normalized.includes("coca")) {
      slots.item = "cola";
    } else if (normalized.includes("woda")) {
      slots.item = "woda";
    } else if (normalized.includes("kawa")) {
      slots.item = "kawa";
    } else if (normalized.includes("herbata")) {
      slots.item = "herbata";
    }
  }



  // Rozpoznawanie ostrości
  if (!slots.spice) {
    if (normalized.includes("łagodna") || normalized.includes("mild")) slots.spice = "łagodna";
    else if (normalized.includes("ostra") || normalized.includes("spicy") || normalized.includes("hot")) slots.spice = "ostra";
  }

  // Sprawdź czy użytkownik składa złożone zamówienie (kilka produktów)
  const hasMultipleItems = (normalized.includes("pizza") && normalized.includes("cola")) ||
    (normalized.includes("pizza") && normalized.includes("frytki")) ||
    (normalized.includes("burger") && normalized.includes("cola")) ||
    (normalized.includes("margarita") && normalized.includes("cola")) ||
    (normalized.includes("pizze") && normalized.includes("cola")) ||
    (normalized.includes("pizze") && normalized.includes("frytki")) ||
    (normalized.includes("pizze") && normalized.includes("coca")) ||
    (normalized.includes("pizze") && normalized.includes("cole")) ||
    (normalized.includes("margarite") && normalized.includes("cole")) ||
    (normalized.includes("margarite") && normalized.includes("cola"));
  if (hasMultipleItems) {
    const items: OrderItem[] = [];
    if (normalized.match(/(\d+)\s*pizze?\s*margarita/)) {
      const m = normalized.match(/(\d+)\s*pizze?\s*margarita/);
      items.push({ name: "pizza margherita", quantity: parseInt(m![1], 10) });
    } else if (normalized.includes("pizza margarita")) {
      items.push({ name: "pizza margherita", quantity: 1 });
    }
    if (normalized.match(/(\d+)\s*cole?/)) {
      const m = normalized.match(/(\d+)\s*cole?/);
      items.push({ name: "cola", quantity: parseInt(m![1], 10) });
    } else if (normalized.includes("cola")) {
      items.push({ name: "cola", quantity: 1 });
    }
    if (normalized.match(/(\d+)\s*frytki/)) {
      const m = normalized.match(/(\d+)\s*frytki/);
      items.push({ name: "frytki", quantity: parseInt(m![1], 10) });
    } else if (normalized.includes("frytki")) {
      items.push({ name: "frytki", quantity: 1 });
    }
    if (normalized.match(/(\d+)\s*burger/)) {
      const m = normalized.match(/(\d+)\s*burger/);
      items.push({ name: "burger", quantity: parseInt(m![1], 10) });
    } else if (normalized.includes("burger")) {
      items.push({ name: "burger", quantity: 1 });
    }
    return {
      speech: `Rozumiem! Chcesz: ${items.map(i=>`${i.quantity}x ${i.name}`).join(", ")}. Potwierdzasz zamówienie?`,
      ui_suggestions: ["Tak", "Nie", "Zmienić"],
      slots: { ...slots, item: "złożone zamówienie", orderItems: items },
      readyToConfirm: true,
    };
  }

  const wantsMenuList = normalized.includes("menu") || 
    normalized.includes("co jest w menu") || 
    normalized.includes("co macie") || 
    normalized.includes("jakie macie");
  if (wantsMenuList && !slots.restaurantId) {
    return {
      speech: "Najpierw wybierz restaurację. Powiedz np. 'Pizza Hut', 'KFC' lub 'McDonald's'.",
      ui_suggestions: ["Pizza Hut", "KFC", "McDonald's"],
      slots: slots,
    };
  }
  if (normalized.includes("pomoc") || normalized.includes("help") || normalized.includes("jak") || normalized.includes("co mogę")) {
    return {
      speech: "Mogę pomóc Ci zamówić jedzenie! Powiedz nazwę restauracji (np. 'Pizza Hut') lub co chcesz zjeść (np. 'pizza', 'frytki').",
      ui_suggestions: ["Pizza Hut", "pizza", "frytki", "cola"],
      slots: slots,
    };
  }
  if (!slots.item) return { speech: "Co podać?", ui_suggestions: ["pizza", "frytki", "burger", "cola"], slots };
  if (!slots.spice && (slots.item === "pizza" || slots.item === "burger")) {
    return { speech: "Łagodna czy ostra?", ui_suggestions: ["Łagodna", "Ostra"], slots };
  }
  return nextStep(ensureDefaults(slots))
  }