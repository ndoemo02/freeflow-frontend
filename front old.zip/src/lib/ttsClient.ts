// src/lib/ttsClient.ts
export async function speakTts(text: string, opts?: { lang?: string; voiceName?: string; gender?: string; audioEncoding?: string }) {
  const body = JSON.stringify({ text, ...(opts || {}) });
  const response = await fetch('http://localhost:3003/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body
  });

  if (!response.ok) {
    throw new Error(`TTS HTTP ${response.status}`);
  }

  const json = await response.json();

  // Preferujemy url jeśli backend go zwróci. W przeciwnym razie obsłużemy legacy base64 audioContent.
  if (json?.url) {
    const audio = new Audio(json.url);
    return new Promise((resolve, reject) => {
      audio.onended = () => resolve(audio);
      audio.onerror = reject;
      audio.play().catch((e) => {
        if (e?.name === 'NotAllowedError') {
          console.warn('TTS blocked by autoplay policy – call unlockAudioOnce() after a user click.');
        }
        reject(e);
      });
    });
  }

  if (json?.audioContent) {
    const mime = 'audio/mpeg';
    const audio = new Audio(`data:${mime};base64,${json.audioContent}`);
    return new Promise((resolve, reject) => {
      audio.onended = () => resolve(audio);
      audio.onerror = reject;
      audio.play().catch((e) => {
        if (e?.name === 'NotAllowedError') {
          console.warn('TTS blocked by autoplay policy – call unlockAudioOnce() after a user click.');
        }
        reject(e);
      });
    });
  }

  throw new Error('TTS: missing url or audioContent');
}