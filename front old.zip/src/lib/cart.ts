export type CartItem = {
  id: string;
  name: string;
  qty: number;
  price: number;
  restaurantId?: string;
  restaurantName?: string;
  menuItemId?: string;
  size?: string;
  category?: string;
  notes?: string;
};
export type Cart = { items: CartItem[]; version?: number };

const KEY = 'ff_cart_v2';

export function loadCart(): Cart {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { items: [], version: 2 };
    const parsed = JSON.parse(raw);
    // Migracja ze starej wersji
    if (parsed && Array.isArray(parsed.items) && !parsed.version) {
      parsed.items = parsed.items.map((i: any) => ({ ...i, price: i.price || 0 }));
      parsed.version = 2;
      saveCart(parsed);
    }
    if (!parsed || !Array.isArray(parsed.items)) return { items: [], version: 2 };
    return parsed;
  } catch {
    return { items: [], version: 2 };
  }
}

export function saveCart(cart: Cart) {
  localStorage.setItem(KEY, JSON.stringify(cart));
}

// Dodawanie pozycji z walidacją restauracji
export function addItem(
  name: string,
  qty = 1,
  notes?: string,
  price = 0,
  restaurantId?: string,
  restaurantName?: string,
  menuItemId?: string,
  size?: string,
  category?: string
) {
  const cart = loadCart();
  const id = menuItemId || name.toLowerCase();
  // Walidacja: wszystkie pozycje muszą być z tej samej restauracji
  if (
    cart.items.length > 0 &&
    restaurantId &&
  cart.items.some((i: CartItem) => i.restaurantId && i.restaurantId !== restaurantId)
  ) {
    // Usuwamy pozycje z innych restauracji
  cart.items = cart.items.filter((i: CartItem) => i.restaurantId === restaurantId);
  }
  const existing = cart.items.find((i: CartItem) => i.id === id);
  if (existing) existing.qty += qty;
  else cart.items.push({ id, name, qty, price, restaurantId, restaurantName, menuItemId, size, category, notes });
  saveCart(cart);
  return cart;
}
// Walidacja koszyka
export function validateCart(cart: Cart): boolean {
  if (!cart.items.length) return false;
  const restId = cart.items[0].restaurantId;
  if (!restId) return false;
  for (const it of cart.items) {
    if (!it.price || it.qty <= 0 || it.restaurantId !== restId) return false;
  }
  return true;
}

// Podsumowanie zamówienia
export function getOrderSummary(cart: Cart) {
  if (!validateCart(cart)) return null;
  return {
    restaurantId: cart.items[0].restaurantId,
    items: cart.items.map((i: CartItem) => ({
      name: i.name,
      menuItemId: i.menuItemId,
      price: i.price,
      quantity: i.qty,
      notes: i.notes,
      size: i.size,
      category: i.category
    })),
    total: cart.items.reduce((sum, i) => sum + i.price * i.qty, 0)
  };
}

// Usuwa pozycje z konkretnej restauracji
export function clearRestaurantItems(restaurantId: string) {
  const cart = loadCart();
  cart.items = cart.items.filter((i: CartItem) => i.restaurantId !== restaurantId);
  saveCart(cart);
}

export function updateItem(id: string, qty: number) {
  const cart = loadCart();
  const it = cart.items.find((i: CartItem) => i.id === id);
  if (it) it.qty = Math.max(0, qty);
  cart.items = cart.items.filter((i: CartItem) => i.qty > 0);
  saveCart(cart);
  return cart;
}

export function clearCart() {
  saveCart({ items: [], version: 2 });
}

