// src/pages/HomeClassic.jsx
import React, { useEffect, useRef, useState } from "react";
import { api } from "../lib/api";
import { speakTts } from "../lib/ttsClient";
import { unlockAudioOnce, isAudioUnlocked } from "../lib/audioGate";
// import { addItem } from "../lib/cart"; // (niewykorzystane – zostaw zakomentowane, by uniknąć warningów)
import ResultsList from "../components/ResultsList";
import { dialogManager as manageTurn } from "../lib/DialogManager";
import { addItem, loadCart, saveCart, clearCart } from "../lib/cart";
  // Walidacja zamówienia (orderItems)
  function validateOrder(slots) {
    if (!slots || !slots.orderItems || !Array.isArray(slots.orderItems) || slots.orderItems.length === 0) return false;
    if (!slots.restaurantId) return false;
    for (const it of slots.orderItems) {
      if (!it.name || !it.quantity || !it.price || it.quantity <= 0 || it.price <= 0) return false;
    }
    return true;
  }

  // Submit zamówienia do backendu
  async function submitOrder(slots) {
    setLoading(true);
    setError("");
    try {
      if (!validateOrder(slots)) throw new Error("Niekompletne dane zamówienia");
      const payload = {
        restaurantId: slots.restaurantId,
        items: slots.orderItems,
        total: slots.orderItems.reduce((sum, it) => sum + (it.price * it.quantity), 0),
      };
      const res = await api("/api/orders", { method: "POST", body: JSON.stringify(payload) });
      if (res.error) throw new Error(res.error || "Błąd składania zamówienia");
      await speak("Zamówienie złożone! Numer: " + (res.orderId || "?"));
      clearCart();
      setDialogSlots({});
      setHits([]);
      setChat((prev) => [...prev, { id: Date.now() + Math.random(), role: "assistant", text: "Zamówienie złożone!" }]);
    } catch (e) {
      setError(e?.message || "Błąd składania zamówienia");
      await speak("Nie udało się złożyć zamówienia. " + (e?.message || "Błąd"));
    } finally {
      setLoading(false);
    }
  }

export default function HomeClassic() {
  const [hits, setHits] = useState([]);
  const [query, setQuery] = useState("");
  const [chat, setChat] = useState([]);
  const [dialogSlots, setDialogSlots] = useState({});
  const [recording, setRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [interim, setInterim] = useState("");
  const [finalText, setFinalText] = useState("");
  const [error, setError] = useState("");
  const [assistantText, setAssistantText] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [activePreference, setActivePreference] = useState('jedzenie');

  const recognitionRef = useRef(null);
  const synthRef = useRef(null);
  const processingRef = useRef(false);
  const speakingRef = useRef(false);
  const lastSpeakPromiseRef = useRef(Promise.resolve());
  const silenceTimerRef = useRef(null);
  const hardStopTimerRef = useRef(null);
  const greetedRef = useRef(false);
  const streamCancelRef = useRef(0);

  // NOWE: akumulator finalText w trakcie sesji SR (eliminuje problem „zamrożonego” stanu w closure)
  const finalStrRef = useRef("");

  // Konfiguracja czasów nagrywania
  const SILENCE_MS = 2200;      // po ilu ms ciszy zatrzymujemy SR
  const MAX_RECORDING_MS = 14000; // twardy limit jednej sesji

  // Ping backendu
  useEffect(() => {
    api("/api/health").catch((e) => console.error("API error", e));
  }, []);

  // Jednorazowe powitanie
  useEffect(() => {
    if (!greetedRef.current) {
      greetedRef.current = true;
      setTimeout(() => {
        lastSpeakPromiseRef.current = lastSpeakPromiseRef.current.then(() =>
          speakNow("Witaj we Freeflow, z nami zamówisz pewnie i szybko")
        );
      }, 300);
    }
  }, []);

  // Inicjalizacja Web Speech API
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      console.warn("SpeechRecognition API not supported in this browser.");
      return;
    }
    const recognition = new SR();
    recognition.lang = "pl-PL";
    recognition.interimResults = true;
    recognition.continuous = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let interimStr = "";
      let finalStr = finalStrRef.current;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const t = res[0].transcript;
        if (res.isFinal) {
          finalStr += (finalStr ? " " : "") + t.trim();
        } else {
          interimStr += t;
        }
      }

      finalStrRef.current = finalStr;
      setInterim(interimStr);
      setFinalText(finalStr);

      const merged = (finalStr + " " + interimStr).trim();
      setQuery(merged);

      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = setTimeout(() => {
        try {
          recognition.stop();
        } catch (_) {}
      }, SILENCE_MS);
    };

    recognition.onerror = (event) => {
      console.error("Speech error:", event.error);
      setRecording(false);
    };

    recognition.onend = () => {
      setRecording(false);
      finalStrRef.current = "";
      setFinalText("");
      setInterim("");
    };

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.stop();
      } catch (_) {}
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (hardStopTimerRef.current) clearTimeout(hardStopTimerRef.current);
      recognitionRef.current = null;
    };
  }, []);

  // TTS z deduplikacją i cache
  const speakNow = async (text) => {
    try {
      speakingRef.current = true;
      setSpeaking(true);
      await speakTts(text, { lang: "pl-PL", voiceName: "pl-PL-Wavenet-D" });
    } catch (e) {
      console.warn("TTS failed", e);
    } finally {
      speakingRef.current = false;
      setSpeaking(false);
    }
  };

  const speak = (text) => {
    lastSpeakPromiseRef.current = lastSpeakPromiseRef.current
      .catch(() => {})
      .then(() => speakNow(text));
    return lastSpeakPromiseRef.current;
  };

  // Typowanie „strumieniowe” odpowiedzi asystenta (UI)
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const streamAssistant = async (text) => {
    const id = Date.now();
    streamCancelRef.current = id;
    setChat((prev) => [...prev, { id, role: "assistant", text: "" }]);
    const words = (text || "").split(/\s+/).filter(Boolean);
    for (let i = 0; i < words.length; i++) {
      if (streamCancelRef.current !== id) return;
      const w = words[i];
      setAssistantText((prev) => (prev ? prev + " " : "") + w);
      setChat((prev) =>
        prev.map((m) => (m.id === id ? { ...m, text: m.text ? m.text + " " + w : w } : m))
      );
      await sleep(40);
    }
  };

  // Body classes (stany UI)
  useEffect(() => {
    document.body.classList.toggle("is-listening", recording);
  }, [recording]);
  useEffect(() => {
    document.body.classList.toggle("is-speaking", speaking);
  }, [speaking]);

  // Klik / Enter / Spacja na logo – start/stop SR
  const handleMicClick = () => {
    // First, try to unlock audio on user gesture (one-time per session)
    // This helps iOS/Chrome allow autoplay of generated TTS audio later.
    try {
      // fire-and-forget, don't block UI
      unlockAudioOnce().then((ok) => {
        if (!ok) {
          // optional: show a message to user later
        }
      });
    } catch (e) {}

    if (processingRef.current || speakingRef.current) return;

    const isSecure =
      location.protocol === "https:" ||
      location.hostname === "localhost" ||
      location.hostname === "127.0.0.1";
    if (!isSecure) setAssistantText("Mikrofon wymaga HTTPS lub localhost.");

    const ensureMic = async () => {
      if (!navigator.mediaDevices?.getUserMedia) return true;
      try {
        const s = await navigator.mediaDevices.getUserMedia({ audio: true });
        s.getTracks().forEach((t) => t.stop());
        return true;
      } catch {
        return false;
      }
    };

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      alert("Twoja przeglądarka nie obsługuje rozpoznawania mowy.");
      return;
    }
    let rec = recognitionRef.current;
    if (!rec) {
      rec = new SR();
      rec.lang = "pl-PL";
      rec.interimResults = true;
      rec.continuous = true;
      rec.maxAlternatives = 1;

      rec.onresult = (event) => {
        let interimStr = "";
        let finalStr = finalStrRef.current;

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const res = event.results[i];
          const t = res[0].transcript;
          if (res.isFinal) finalStr += (finalStr ? " " : "") + t.trim();
          else interimStr += t;
        }

        finalStrRef.current = finalStr;
        setInterim(interimStr);
        setFinalText(finalStr);
        const merged = (finalStr + " " + interimStr).trim();
        setQuery(merged);
      };

      rec.onerror = (event) => {
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          setAssistantText("Zezwól na dostęp do mikrofonu w przeglądarce.");
        } else if (event.error === "no-speech") {
          setAssistantText("Nie usłyszałem wypowiedzi. Spróbuj ponownie.");
        }
        setRecording(false);
      };

      rec.onend = () => {
        setRecording(false);
        finalStrRef.current = "";
      };

      recognitionRef.current = rec;
    }

    if (recording) {
      try {
        rec.stop();
      } catch (e) {
        console.error(e);
      }
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (hardStopTimerRef.current) clearTimeout(hardStopTimerRef.current);
      setRecording(false);
    } else {
      (async () => {
        setQuery("");
        setInterim("");
        setFinalText("");
        finalStrRef.current = "";
        const ok = await ensureMic();
        if (!ok) {
          setAssistantText("Brak uprawnień do mikrofonu.");
          return;
        }
        try {
          rec.start();
        } catch (e) {
          console.error("start failed", e);
          return;
        }
        setRecording(true);
        if (hardStopTimerRef.current) clearTimeout(hardStopTimerRef.current);
        hardStopTimerRef.current = setTimeout(() => {
          try {
            rec.stop();
          } catch (_) {}
        }, MAX_RECORDING_MS);
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          try {
            rec.stop();
          } catch (_) {}
        }, SILENCE_MS);
      })();
    }
  };

  const handleLogoKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleMicClick();
    }
  };

  // onUserGesture exposed to buttons to unlock audio once per session
  const onUserGesture = async () => {
    const ok = await unlockAudioOnce();
    if (!ok) {
      setAssistantText("Dotknij ekran, aby włączyć dźwięk");
    }
  };

  // Pipeline zapytania (DialogManager)
  const runQueryPipeline = async (q) => {
    const trimmed = (q || "").trim();
    console.log("🚀 runQueryPipeline called with:", trimmed);
    if (!trimmed) return;
    if (processingRef.current) {
      console.log("⚠️ Already processing, ignoring:", trimmed);
      return;
    }
    processingRef.current = true;
    setLoading(true);
    setError("");

    try {
      console.log("📝 Adding to chat:", trimmed);
      setChat((prev) => [
        ...prev,
        { id: Date.now() + Math.random(), role: "user", text: trimmed },
      ]);

      setFinalText("");
      setInterim("");

      console.log("🤖 Calling manageTurn with:", trimmed, "slots:", dialogSlots);
      const resp = await manageTurn(trimmed, dialogSlots);
      console.log("🤖 manageTurn response:", resp);
      setDialogSlots(resp.slots || {});

      if (resp.speech) {
        await streamAssistant(resp.speech);
        await speak(resp.speech);
      }

      if (resp.action === "search_restaurants") {
        console.log("Restaurants found:", resp.slots);
      } else if (resp.action === "search_menu") {
        console.log("Menu items found:", resp.slots);
      } else if (resp.action === "add_to_cart") {
        // Dodaj do koszyka z pełnymi danymi
        if (resp.slots && resp.slots.orderItems && resp.slots.orderItems.length > 0) {
          const last = resp.slots.orderItems[resp.slots.orderItems.length - 1];
          addItem(last.name, last.quantity, last.notes);
        }
        await speak("Dodałem do koszyka! Chcesz coś jeszcze?");
      } else if (resp.action === "checkout") {
        // Najpierw złóż zamówienie przez API, potem przekieruj
        await speak("Składam zamówienie...");
        await submitOrder(resp.slots);
        await speak("Przekierowuję do panelu zamówień...");
        window.location.href = "/panel/customer";
        return;
      }

      if (resp.readyToConfirm) {
        // Jeśli mamy kompletne dane zamówienia, złóż zamówienie
        if (validateOrder(resp.slots)) {
          await speak("Znalazłem kompletne zamówienie. Składam...");
          await submitOrder(resp.slots);
        } else {
          // Stary flow: podpowiedzi z places
          const term = resp.slots?.item || trimmed;
          const res = await api(`/api/places?q=${encodeURIComponent(term)}`);
          const list = Array.isArray(res?.results) ? res.results : Array.isArray(res) ? res : [];
          setHits(list);
        }
      }
    } catch (e) {
      setError(e?.message || "Błąd");
    } finally {
      setLoading(false);
      processingRef.current = false;
    }
  };

  // Po zakończeniu nagrywania – uruchom pipeline
  useEffect(() => {
    if (!recording && query.trim()) {
      runQueryPipeline(query);
    }
  }, [recording]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section className="ff-hero bg-hero min-h-screen flex items-center justify-center relative">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-orange-400/30 rounded-full animate-float"></div>
        <div className="absolute top-3/4 right-1/4 w-1 h-1 bg-blue-400/40 rounded-full animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-3/4 w-1.5 h-1.5 bg-purple-400/30 rounded-full animate-float" style={{animationDelay: '2s'}}></div>
      </div>

      {/* Main content */}
      <div className="ff-stack relative z-10 max-w-4xl mx-auto px-4">
        {/* Logo with enhanced animations */}
        <div className="ff-logo-wrap mb-8 animate-fade-in-up">
          <div className="relative">
            <img
              className={`ff-logo transition-all duration-500 ${recording ? "is-listening animate-pulse-slow scale-110" : "hover:scale-105"} cursor-pointer`}
              src="/images/Freeflowlogo.png"
              alt="FreeFlow logo"
              role="button"
              tabIndex={0}
              aria-pressed={recording}
              aria-label="Naciśnij, aby mówić"
              onClick={handleMicClick}
              onKeyDown={handleLogoKeyDown}
            />
            {recording && (
              <div className="absolute inset-0 rounded-full border-4 border-orange-400/50 animate-ping"></div>
            )}
          </div>
        </div>

        {/* Enhanced search form */}
        <form
          className="ff-search animate-slide-in-right"
          onSubmit={(e) => {
            e.preventDefault();
            runQueryPipeline(query);
          }}
        >
          <div className="flex gap-4 items-center">
            <input
              className="input-glass flex-1 text-lg"
              placeholder="Powiedz lub wpisz..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  console.log("🚀 Enter pressed, calling runQueryPipeline with:", query);
                  runQueryPipeline(query);
                }
              }}
            />
            <button
              className={`btn-glass px-6 py-3 rounded-full transition-all duration-300 ${
                recording 
                  ? "bg-red-500/20 border-red-400/50 animate-pulse-slow" 
                  : "hover:bg-orange-500/20 hover:border-orange-400/50"
              }`}
              type="button"
              aria-label="Mów"
              onClick={handleMicClick}
              data-recording={recording}
            >
              <span className="text-2xl" aria-hidden="true">
                {recording ? "🛑" : "🎙️"}
              </span>
            </button>
          </div>
          {/* One-time audio enable banner/button */}
          {!isAudioUnlocked() && (
            <div className="mt-4">
              <button className="btn btn-primary" type="button" onClick={onUserGesture}>
                🔊 Włącz dźwięk
              </button>
            </div>
          )}
          
          {/* Status indicator */}
          {recording && (
            <div className="mt-4 flex items-center gap-2 text-orange-300 animate-fade-in-up">
              <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
              <span className="text-sm">Słucham...</span>
            </div>
          )}
          
          {speaking && (
            <div className="mt-4 flex items-center gap-2 text-blue-300 animate-fade-in-up">
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
              <span className="text-sm">Mówię...</span>
            </div>
          )}
        </form>
      </div>

      {/* Enhanced Chat bubbles */}
      {!!chat.length && (
        <div className="ff-chat absolute bottom-8 left-4 right-4 max-w-2xl mx-auto space-y-4 animate-fade-in-up" aria-live="polite">
          {chat.map((m, index) => (
            <div
              key={m.id}
              className={`glass-card p-4 max-w-xs ${
                m.role === "assistant" 
                  ? "ml-0 mr-auto bg-blue-500/10 border-blue-400/20" 
                  : "ml-auto mr-0 bg-orange-500/10 border-orange-400/20"
              } animate-slide-in-right`}
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <div className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  m.role === "assistant" ? "bg-blue-500/20" : "bg-orange-500/20"
                }`}>
                  {m.role === "assistant" ? "🤖" : "👤"}
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm leading-relaxed">{m.text}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Enhanced Status Messages */}
      {error && (
        <div className="glass-card p-4 max-w-md mx-auto mt-8 bg-red-500/10 border-red-400/20 animate-fade-in-up" role="status">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center">
              ⚠️
            </div>
            <span className="text-red-200">{error}</span>
          </div>
        </div>
      )}
      
      {loading && (
        <div className="glass-card p-6 max-w-md mx-auto mt-8 bg-blue-500/10 border-blue-400/20 animate-fade-in-up" role="status">
          <div className="flex items-center gap-4">
            <div className="loading-spinner"></div>
            <div className="flex-1">
              <div className="skeleton skeleton-line short mb-2"></div>
              <div className="skeleton skeleton-line medium"></div>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-blue-300">
            <div className="loading-dots">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <span className="text-sm">Szukam...</span>
          </div>
        </div>
      )}
      
      {!!hits.length && (
        <div className="absolute bottom-8 left-4 right-4 max-w-4xl mx-auto animate-fade-in-up">
          <ResultsList results={hits} />
        </div>
      )}

      {/* Preference Tiles - positioned under search form */}
      <div className="mt-6 w-full">
        <div className="grid grid-cols-3 gap-3 animate-fade-in-up">
          <div 
            className={`preference-tile ${activePreference === 'jedzenie' ? 'active' : ''}`} 
            onClick={() => setActivePreference('jedzenie')}
          >
            <span className="preference-tile-icon">
              <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
              </svg>
            </span>
            <h3 className="preference-tile-title">Restauracje</h3>
          </div>
          <div 
            className={`preference-tile ${activePreference === 'taxi' ? 'active' : ''}`} 
            onClick={() => setActivePreference('taxi')}
          >
            <span className="preference-tile-icon">
              <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"/>
                <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05A2.5 2.5 0 0115.95 16H17a1 1 0 001-1V8a1 1 0 00-1-1h-3z"/>
              </svg>
            </span>
            <h3 className="preference-tile-title">Transport</h3>
          </div>
          <div 
            className={`preference-tile ${activePreference === 'hotel' ? 'active' : ''}`} 
            onClick={() => setActivePreference('hotel')}
          >
            <span className="preference-tile-icon">
              <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a1 1 0 110 2h-3a1 1 0 01-1-1v-2a1 1 0 00-1-1H9a1 1 0 00-1 1v2a1 1 0 01-1 1H4a1 1 0 110-2V4zm3 1h2v2H7V5zm2 4H7v2h2V9zm2-4h2v2h-2V5zm2 4h-2v2h2V9z" clipRule="evenodd"/>
              </svg>
            </span>
            <h3 className="preference-tile-title">Noclegi</h3>
          </div>
        </div>
      </div>
    </section>
  );
}
