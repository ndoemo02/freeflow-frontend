export default function CartPage() {
  return (
    <div className="container" style={{ padding: '24px 16px', maxWidth: 860, margin: '92px auto' }}>
      <h1 className="ff-h1" style={{ marginBottom: 8 }}>Koszyk</h1>
      <p className="ff-muted">Tu pojawi się podsumowanie zamówienia.</p>
    </div>
  )
}


