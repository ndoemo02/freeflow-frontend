import React from 'react'

export default function Orders() {
  return (
    <main className="page">
      <section className="container">
        <h1 className="ff-h1">Historia Zamówień</h1>
        <p className="ff-lead">Tu będą Twoje zamówienia.</p>
        <div className="ff-card mt-6">Brak zamówień.</div>
      </section>
    </main>
  )
}


