
  # Floating Contextual Card

  This is a code bundle for Floating Contextual Card. The original project is available at https://www.figma.com/design/DJGLKvl5jy4LZ8PILE9GZ4/Floating-Contextual-Card.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  